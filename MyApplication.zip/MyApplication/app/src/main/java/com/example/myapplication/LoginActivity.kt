package com.example.myapplication

// LoginActivity.kt
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.app.ApiConfig
import kotlinx.android.synthetic.main.activity_login.btnLogin
import kotlinx.android.synthetic.main.activity_login.editTextEmail
import kotlinx.android.synthetic.main.activity_login.editTextPassword
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLogin.setOnClickListener {
            login()
        }

        val txtRegist: TextView = findViewById(R.id.textRegister)
        txtRegist.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.textRegister -> {
                    val intent = Intent(this, RegisterActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    fun login() {
        if (editTextEmail.text.isEmpty()) {
            editTextEmail.error = "Kolom Email Tidak Boleh Kosong"
            editTextEmail.requestFocus()
            return

        } else if (editTextPassword.text.isEmpty()) {
            editTextPassword.error = "Kolom Password Tidak Boleh Kosong"
            editTextPassword.requestFocus()
            return
        }

        ApiConfig.instanceRetrofit.login(
            editTextEmail.text.toString(),
            editTextPassword.text.toString()
        ).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Terjadi kesalahan"

                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                // Kegagalan koneksi atau error lainnya
                // Anda dapat menangani kegagalan sesuai kebutuhan
                // Misalnya, menampilkan pesan kesalahan kepada pengguna
                // atau melakukan tindakan tertentu seperti mencoba kembali
                val errorMessage = "Koneksi gagal atau terjadi kesalahan: ${t.message}"
                // Tampilkan pesan kesalahan atau lakukan penanganan yang sesuai
            }
        })
    }
}


