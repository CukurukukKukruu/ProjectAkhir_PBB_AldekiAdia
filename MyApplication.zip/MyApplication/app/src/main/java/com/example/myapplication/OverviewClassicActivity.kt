package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class OverviewClassicActivity : AppCompatActivity(), View.OnClickListener, BottomNavigationView.OnNavigationItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_overview_classic)

        // Inisialisasi ImageView
        val Back: ImageView = findViewById(R.id.button_back)

        // Menambahkan OnClickListener pada ImageView
        Back.setOnClickListener(this)


        // Inisialisasi BottomNavigationView
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationBar)
        bottomNavigationView.setOnNavigationItemSelectedListener(this)
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.button_back -> {
                    val intent = Intent(this, ClassicActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                return true
            }
            R.id.profile -> {
                // Implementasi untuk menu Profile
                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
                return true
            }
            //R.id.content -> {
            // Implementasi untuk menu Settings
            //val intent = Intent(this, SettingsActivity::class.java)
            // startActivity(intent)
            // return true
            // }
        }
        return false
    }
}
