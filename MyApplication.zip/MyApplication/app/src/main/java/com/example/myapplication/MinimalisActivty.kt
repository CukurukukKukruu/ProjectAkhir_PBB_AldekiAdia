package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MinimalisActivty : AppCompatActivity(), View.OnClickListener, BottomNavigationView.OnNavigationItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_minimalis)

        val cl1: ImageView = findViewById(R.id.Classic1)
        val cl2: ImageView = findViewById(R.id.Classic2)
        val cl3: ImageView = findViewById(R.id.Classic3)
        val cl4: ImageView = findViewById(R.id.Classic4)

        // Menambahkan OnClickListener pada ImageView
        cl1.setOnClickListener(this)
        cl2.setOnClickListener(this)
        cl3.setOnClickListener(this)
        cl4.setOnClickListener(this)

        // Inisialisasi BottomNavigationView
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationBar)
        bottomNavigationView.setOnNavigationItemSelectedListener(this)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home -> {
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
                return true
            }
            R.id.profile -> {
                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
                return true
            }
            //R.id.content -> {
            // Implementasi untuk menu Settings
            //val intent = Intent(this, SettingsActivity::class.java)
            // startActivity(intent)
            // return true
            // }
        }
        return false
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.Classic1 -> {
                    val intent = Intent(this, OverviewMinimalisActivity::class.java)
                    startActivity(intent)
                }
                R.id.Classic2 -> {
                    val intent = Intent(this, OverviewMinimalisActivity::class.java)
                    startActivity(intent)
                }
                R.id.Classic3 -> {
                    val intent = Intent(this, OverviewMinimalisActivity::class.java)
                    startActivity(intent)
                }
                R.id.Classic4 -> {
                    val intent = Intent(this, OverviewMinimalisActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

}
