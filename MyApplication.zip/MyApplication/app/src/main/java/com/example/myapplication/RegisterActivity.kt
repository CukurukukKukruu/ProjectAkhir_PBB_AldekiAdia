package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.app.ApiConfig
import kotlinx.android.synthetic.main.activity_register.btnRegister
import kotlinx.android.synthetic.main.activity_register.editTextEmail
import kotlinx.android.synthetic.main.activity_register.editTextNumberphone
import kotlinx.android.synthetic.main.activity_register.editTextPassword
import kotlinx.android.synthetic.main.activity_register.editTextUsername
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnRegister.setOnClickListener {
            register()
        }

        val txtLogin: TextView = findViewById(R.id.textLogin)
        txtLogin.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.textLogin -> {
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    fun register() {
        if (editTextUsername.text.isEmpty()) {
            editTextUsername.error = "Kolom Nama Tidak Boleh Kosong"
            editTextUsername.requestFocus()
            return
        } else if (editTextEmail.text.isEmpty()) {
            editTextEmail.error = "Kolom Email Tidak Boleh Kosong"
            editTextEmail.requestFocus()
            return
        } else if (editTextNumberphone.text.isEmpty()) {
            editTextNumberphone.error = "Kolom Nomor Hp Tidak Boleh Kosong"
            editTextNumberphone.requestFocus()
            return
        } else if (editTextPassword.text.isEmpty()) {
            editTextPassword.error = "Kolom Password Tidak Boleh Kosong"
            editTextPassword.requestFocus()
            return
        }

        ApiConfig.instanceRetrofit.register(
            editTextUsername.text.toString(),
            editTextEmail.text.toString(),
            editTextNumberphone.text.toString(),
            editTextPassword.text.toString()
        ).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Terjadi kesalahan"

                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                val errorMessage = "Koneksi gagal atau terjadi kesalahan: ${t.message}"
            }
        })
    }
}
